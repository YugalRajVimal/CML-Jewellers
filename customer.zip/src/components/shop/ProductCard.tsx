"use client";

import Link from "next/link";
import { motion, useReducedMotion } from "framer-motion";
import { Eye, Heart, Pin, ShoppingBag, Star } from "lucide-react";
import type { Product } from "@/lib/types";
import { useEffect } from "react";

// Backend stores prices as integer paise/cents — divide by 100 for display.
function formatPrice(value: number) {
  return `₹${(value / 100).toLocaleString("en-IN", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

function RatingStars({ value, count }: { value: number; count?: number }) {
  const rounded = Math.round(value);
  return (
    <div className="flex items-center gap-1">
      <div className="flex items-center gap-0.5" aria-label={`Rated ${value} out of 5`}>
        {Array.from({ length: 5 }).map((_, i) => (
          <Star
            key={i}
            size={13}
            strokeWidth={1.5}
            className={
              i < rounded
                ? "fill-[var(--color-gold,#b98a4e)] text-[var(--color-gold,#b98a4e)]"
                : "text-[var(--color-stone-light,#d8c9ab)]"
            }
          />
        ))}
      </div>
      {!!count && <span className="text-[11px] text-[var(--color-stone,#9a8f7c)]">({count})</span>}
    </div>
  );
}

// Builds "Yellow Gold • 18K • Pearl" from the real attributes object,
// skipping anything the product doesn't have (e.g. stone: "None").
function attributeLine(attributes: Record<string, string> | undefined): string {
  if (!attributes) return "";
  const parts = [attributes.metal, attributes.purity, attributes.stone].filter(
    (v) => v && v.toLowerCase() !== "none"
  );
  return parts.join(" • ");
}

const quickActions = [
  { Icon: Eye, label: "Quick view" },
  { Icon: Heart, label: "Add to wishlist" },
  { Icon: ShoppingBag, label: "Add to cart" },
];

export function ProductCard({ product, index = 0 }: { product: Product; index?: number }) {
  const reduce = useReducedMotion();
  const p = product as any;
  const id = p._id ?? p.id;
  const image = product.images?.[0];
  const hasDiscount = p.discountPercent > 0;
  const inStock = p.inStock !== false;
  const lowStock = inStock && typeof p.totalAvailable === "number" && p.totalAvailable > 0 && p.totalAvailable <= 5;
  const details = attributeLine(p.attributes);

  // INSERT_YOUR_CODE
  // Log the product prop whenever it changes

  useEffect(() => {
    console.log("Product prop:", product);
  }, [product]);

  return (
    <motion.div
      initial={reduce ? undefined : { opacity: 0, y: 32, scale: 0.98 }}
      whileInView={{ opacity: 1, y: 0, scale: 1 }}
      viewport={{ once: true, amount: 0.3 }}
      transition={{ duration: 0.7, delay: index * 0.05, ease: [0.32, 0.72, 0, 1] }}
      className="group relative rounded-xl border border-[var(--color-cream-light,#f7ece1)] bg-gradient-to-br from-[#fff8f0] to-[var(--color-cream,#fcf5eb)] shadow-lg hover:shadow-xl hover:-translate-y-1 transition-all duration-400"
      style={{ overflow: "visible" }}
    >
      <Link
        href={`/product/${p.slug ?? id}`}
        className="block rounded-xl overflow-hidden"
        style={{ boxShadow: "0 8px 40px 0 rgba(195,168,129,0.12)" }}
      >
        <div className="relative aspect-square overflow-hidden rounded-xl bg-[var(--color-cream-deep,#f3e7d6)] border border-[var(--color-cream-light,#f7ece1)] transition-all duration-300 group-hover:border-[var(--color-gold,#b98a4e)]">
          {p.isFeatured && (
            <span className="absolute left-3 top-3 z-20 flex h-8 w-8 -rotate-12 items-center justify-center rounded-full bg-gradient-to-b from-[var(--color-gold-light,#efd6ae)] to-[var(--color-gold,#b98a4e)] shadow-gold-glow text-white">
              <Pin size={15} strokeWidth={2} className="rotate-12" />
            </span>
          )}

          {!p.isFeatured && p.isNewArrival && (
            <span className="absolute left-3 top-3 z-20 rounded-full bg-[var(--color-ink,#1c1c1c)] px-3 py-1 text-[11px] font-semibold tracking-wide text-white">
              New
            </span>
          )}

          {hasDiscount && (
            <span className="absolute right-3 top-3 z-20 rounded-xl bg-gradient-to-r from-[var(--color-ink,#1c1c1c)] via-[var(--color-gold,#b98a4e)] to-[var(--color-gold-light,#efd6ae)] px-3 py-1 text-xs font-semibold text-white shadow-lg tracking-wide">
              Sale &nbsp; • &nbsp; {p.discountPercent}% Off
            </span>
          )}

          {!inStock && (
            <span className="absolute inset-x-0 bottom-0 z-20 bg-[var(--color-ink,#1c1c1c)]/85 py-1.5 text-center text-xs tracking-wide text-white">
              Out of stock
            </span>
          )}

          {image ? (
            <img
              src={image}
              alt={product.name}
              className="h-full w-full object-cover object-center scale-105 group-hover:scale-110 transition-transform duration-500 will-change-transform rounded-xl"
              draggable={false}
            />
          ) : (
            <div className="absolute inset-0 flex items-center justify-center text-stone-400 rounded-xl">
              <span className="text-2xl">No Image</span>
            </div>
          )}

          {/* Quick-actions */}
          <div className="pointer-events-none absolute inset-x-0 bottom-0 flex justify-center gap-3 pb-5 opacity-0 transition-all duration-500 ease-out group-hover:pointer-events-auto group-hover:opacity-100 translate-y-3 group-hover:translate-y-0">
            {quickActions.map(({ Icon, label }, i) => (
              <button
                key={label}
                type="button"
                aria-label={label}
                onClick={(e) => e.preventDefault()}
                style={{ transitionDelay: `${i * 70}ms` }}
                className="flex h-10 w-10 items-center justify-center rounded-full shadow-xl backdrop-blur-lg bg-white/70 border border-[var(--color-gold-light,#efd6ae)] ring-1 ring-[var(--color-gold-light,#efd6ae)] text-[var(--color-gold,#b98a4e)] hover:bg-[var(--color-gold,#b98a4e)] hover:text-white hover:scale-110 transition-all duration-300"
              >
                <Icon size={17} strokeWidth={1.5} />
              </button>
            ))}
          </div>

          {/* Floating gold sparkle on hover */}
          <div className="pointer-events-none absolute right-6 bottom-7 z-30 hidden group-hover:block animate-fade-in">
            <svg width="36" height="36" fill="none" viewBox="0 0 64 64">
              <circle cx="32" cy="32" r="12" fill="url(#gold-glow)" fillOpacity="0.12" />
              <circle cx="32" cy="32" r="4" fill="url(#gold-med)" />
              <defs>
                <radialGradient id="gold-glow" cx="0" cy="0" r="1" gradientTransform="rotate(45) scale(20)">
                  <stop stopColor="#efd6ae" />
                  <stop offset="1" stopColor="#b98a4e" stopOpacity="0" />
                </radialGradient>
                <radialGradient id="gold-med" cx="0" cy="0" r="1" gradientTransform="rotate(0) scale(8)">
                  <stop stopColor="#b98a4e" />
                  <stop offset="1" stopColor="#efd6ae" stopOpacity="0" />
                </radialGradient>
              </defs>
            </svg>
          </div>
        </div>

        <div className="pt-5 px-6 pb-4">
          {details && (
            <p className="mb-1 text-xs uppercase tracking-wide text-[var(--color-stone,#9a8f7c)]">{details}</p>
          )}

          <div className="flex items-start justify-between gap-3">
            <p
              className="font-marcellus text-xl font-semibold text-[var(--color-ink,#22160f)] truncate tracking-wide"
              title={product.name}
            >
              {product.name}
            </p>
            <RatingStars value={p.ratingAvg ?? 0} count={p.ratingCount} />
          </div>

          <div className="mt-2 flex items-end justify-between gap-2">
            <div className="flex items-end gap-2">
              {hasDiscount && (
                <span className="text-base text-[var(--color-stone,#ac9777)] line-through decoration-wavy decoration-[var(--color-gold,#d3b779)]">
                  {formatPrice(p.mrp)}
                </span>
              )}
              <span className="text-lg font-bold text-[var(--color-gold,#b98a4e)] drop-shadow-gold">
                {formatPrice(p.basePrice)}
              </span>
            </div>

            {lowStock && (
              <span className="text-[11px] font-medium text-[var(--color-maroon,#8a2e1f)]">
                Only {p.totalAvailable} left
              </span>
            )}
          </div>

          {p.variantCount > 1 && (
            <p className="mt-1 text-[11px] text-[var(--color-stone,#9a8f7c)]">
              {p.variantCount} variants available
            </p>
          )}
        </div>
      </Link>
      {/* Premium border highlight */}
      <div className="pointer-events-none absolute inset-0 rounded-xl border-2 border-transparent group-hover:border-[var(--color-gold,#b98a4e)] group-hover:shadow-gold-glow transition-all duration-300 z-10" />
    </motion.div>
  );
}